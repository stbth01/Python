name = raw_input('Enter your name:')
print 'Hello', name
